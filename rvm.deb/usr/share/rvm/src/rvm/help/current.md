
    $ rvm current

Print the current Ruby version and the name of any gemset being used.
